import { createContext, useState, useEffect } from "react";
import { getToken, logout } from "../routes/authService";
import { decodeToken } from "../services/tokenService";
import { login as authLogin } from "../routes/authService";

export const AuthContext = createContext();

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  
  const [activeSection, setActiveSection] = useState("users");

  useEffect(() => {
    const token = getToken();
    if (token) {
      const decodedUser = decodeToken(token);
      console.log("Decoded user:", decodedUser);

      if (decodedUser) {
        setUser(decodedUser);
      } else {
        logout();
      }
    }
    setLoading(false);
  }, []);
  

  const loginUser = async (username, password) => {
    try {
      const token = await authLogin({ username, password });
      if (token) {
        // Persist the token (which should be a string) in localStorage
        localStorage.setItem("token", token);
  
        // Decode the token to get user data
        const decodedUser = decodeToken(token);
        console.log("Decoded user:", decodedUser);
        setUser(decodedUser);
        return decodedUser;
      } else {
        throw new Error("Received an invalid token from the server");
      }
    } catch (error) {
      console.error("Login failed:", error.response?.data || error.message);
      throw error;
    }
  };
  

  const logoutUser = () => {
    logout();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, loginUser, logoutUser,activeSection, setActiveSection }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
