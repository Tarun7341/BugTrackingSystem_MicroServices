// src/components/TicketTable.jsx
import React from "react";

const TicketTable = ({
  tickets,
  editingTicket,
  editingTicketUserIdsText,
  onEditTicketClick,
  onCancelEdit,
  onUpdateTicket,
  onDeleteTicket,
  onEditingTicketChange,
  onEditingTicketUserIdsTextChange,
}) => {
  // For testers, status options are limited to "Open" and "Closed".
  const testerStatusOptions = ["Open", "Closed"];
  const typeOptions = ["Bug", "Feature", "Task"];
  const severityOptions = ["Minor", "Major", "Critical"];
  
  return (
    <section>
      
      <table className="table table-bordered table-striped">
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Status</th>
            <th>Type</th>
            <th>Severity</th>
            <th>Steps to Reproduce</th>
            <th>Project ID</th>
            <th>User IDs</th>
            <th style={{ width: "220px" }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {tickets && tickets.length > 0 ? (
            tickets.map((ticket) => (
              <tr key={ticket.id}>
                <td>{ticket.id}</td>
                <td>
                  {editingTicket && editingTicket.id === ticket.id ? (
                    <input
                      type="text"
                      className="form-control"
                      value={editingTicket.title}
                      onChange={(e) =>
                        onEditingTicketChange({
                          ...editingTicket,
                          title: e.target.value,
                        })
                      }
                    />
                  ) : (
                    ticket.title
                  )}
                </td>
                <td>
                  {editingTicket && editingTicket.id === ticket.id ? (
                    <input
                      type="text"
                      className="form-control"
                      value={editingTicket.description}
                      onChange={(e) =>
                        onEditingTicketChange({
                          ...editingTicket,
                          description: e.target.value,
                        })
                      }
                    />
                  ) : (
                    ticket.description
                  )}
                </td>
                <td>
                  {editingTicket && editingTicket.id === ticket.id ? (
                    <select
                      className="form-select form-select-sm"
                      value={editingTicket.status}
                      onChange={(e) =>
                        onEditingTicketChange({
                          ...editingTicket,
                          status: e.target.value,
                        })
                      }
                    >
                      {testerStatusOptions.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  ) : (
                    ticket.status
                  )}
                </td>
                <td>
                  {editingTicket && editingTicket.id === ticket.id ? (
                    <select
                      className="form-select form-select-sm"
                      value={editingTicket.type}
                      onChange={(e) =>
                        onEditingTicketChange({
                          ...editingTicket,
                          type: e.target.value,
                        })
                      }
                    >
                      {typeOptions.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  ) : (
                    ticket.type
                  )}
                </td>
                <td>
                  {editingTicket && editingTicket.id === ticket.id ? (
                    <select
                      className="form-select form-select-sm"
                      value={editingTicket.severity}
                      onChange={(e) =>
                        onEditingTicketChange({
                          ...editingTicket,
                          severity: e.target.value,
                        })
                      }
                    >
                      {severityOptions.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  ) : (
                    ticket.severity
                  )}
                </td>
                <td>
                  {editingTicket && editingTicket.id === ticket.id ? (
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      value={editingTicket.stepstoReproduce}
                      onChange={(e) =>
                        onEditingTicketChange({
                          ...editingTicket,
                          stepstoReproduce: e.target.value,
                        })
                      }
                    />
                  ) : (
                    ticket.stepstoReproduce
                  )}
                </td>
                <td>
                  {editingTicket && editingTicket.id === ticket.id ? (
                    <input
                      type="number"
                      className="form-control form-control-sm"
                      value={editingTicket.projectId || ""}
                      onChange={(e) =>
                        onEditingTicketChange({
                          ...editingTicket,
                          projectId: e.target.value
                            ? parseInt(e.target.value, 10)
                            : null,
                        })
                      }
                    />
                  ) : (
                    ticket.projectId
                  )}
                </td>
                <td>
                  {editingTicket && editingTicket.id === ticket.id ? (
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      value={editingTicketUserIdsText}
                      placeholder="Enter user IDs (comma separated)"
                      onChange={(e) =>
                        onEditingTicketUserIdsTextChange(e.target.value)
                      }
                    />
                  ) : ticket.userId && ticket.userId.length > 0 ? (
                    ticket.userId.join(", ")
                  ) : (
                    "-"
                  )}
                </td>
                <td>
                  {editingTicket && editingTicket.id === ticket.id ? (
                    <>
                      <button
                        className="btn btn-success btn-sm me-2"
                        onClick={onUpdateTicket}
                      >
                        Save
                      </button>
                      <button
                        className="btn btn-secondary btn-sm"
                        onClick={onCancelEdit}
                      >
                        Cancel
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        className="btn btn-primary btn-sm me-2"
                        onClick={() => onEditTicketClick(ticket)}
                      >
                        Edit
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => onDeleteTicket(ticket.id)}
                      >
                        Delete
                      </button>
                    </>
                  )}
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="10">No tickets available.</td>
            </tr>
          )}
        </tbody>
      </table>
    </section>
  );
};

export default TicketTable;
