// src/components/AddTicketForm.jsx
import React from "react";

const AddTicketForm = ({
  newTicketTitle,
  newTicketDescription,
  newTicketStatus,
  newTicketType,
  newTicketSeverity,
  newTicketSteps,
  newTicketProjectId,
  onNewTicketTitleChange,
  onNewTicketDescriptionChange,
  onNewTicketStatusChange,
  onNewTicketTypeChange,
  onNewTicketSeverityChange,
  onNewTicketStepsChange,
  onNewTicketProjectIdChange,
  onAddTicket,
  onCancelAddTicket,
}) => {
  // Prevent default form submission so we can handle it manually inside onAddTicket
  const handleSubmit = (e) => {
    e.preventDefault();
    onAddTicket(e);
  };

  return (
    // The modal wrapper uses inline styles for demonstration. Replace with your preferred CSS.
    <div
      className="modal fade show"
      style={{
        display: "block",
        backgroundColor: "rgba(0, 0, 0, 0.5)",
      }}
      tabIndex="-1"
    >
      <div className="modal-dialog">
        <div className="modal-content">
          {/* Modal Header */}
          <div className="modal-header">
            <h4 className="modal-title">Add New Ticket</h4>
            <button
              type="button"
              className="btn-close"
              aria-label="Close"
              onClick={onCancelAddTicket}
            ></button>
          </div>
          {/* Modal Body with Form */}
          <div className="modal-body">
            <form onSubmit={handleSubmit}>
              <div className="mb-2">
                <label htmlFor="ticketTitle" className="form-label">
                  Title:
                </label>
                <input
                  type="text"
                  id="ticketTitle"
                  className="form-control"
                  value={newTicketTitle}
                  onChange={(e) => onNewTicketTitleChange(e.target.value)}
                  required
                />
              </div>
              <div className="mb-2">
                <label htmlFor="ticketDescription" className="form-label">
                  Description:
                </label>
                <input
                  type="text"
                  id="ticketDescription"
                  className="form-control"
                  value={newTicketDescription}
                  onChange={(e) =>
                    onNewTicketDescriptionChange(e.target.value)
                  }
                  required
                />
              </div>
              <div className="mb-2">
                <label htmlFor="ticketStatus" className="form-label">
                  Status:
                </label>
                <select
                  id="ticketStatus"
                  className="form-select"
                  value={newTicketStatus}
                  onChange={(e) => onNewTicketStatusChange(e.target.value)}
                  required
                >
                  <option value="">Select Status</option>
                  <option value="Open">Open</option>
                  <option value="Closed">Closed</option>
                </select>
              </div>
              <div className="mb-2">
                <label htmlFor="ticketType" className="form-label">
                  Type:
                </label>
                <select
                  id="ticketType"
                  className="form-select"
                  value={newTicketType}
                  onChange={(e) => onNewTicketTypeChange(e.target.value)}
                  required
                >
                  <option value="">Select Type</option>
                  <option value="Bug">Bug</option>
                  <option value="Feature">Feature</option>
                  <option value="Task">Task</option>
                </select>
              </div>
              <div className="mb-2">
                <label htmlFor="ticketSeverity" className="form-label">
                  Severity:
                </label>
                <select
                  id="ticketSeverity"
                  className="form-select"
                  value={newTicketSeverity}
                  onChange={(e) =>
                    onNewTicketSeverityChange(e.target.value)
                  }
                  required
                >
                  <option value="">Select Severity</option>
                  <option value="Minor">Minor</option>
                  <option value="Major">Major</option>
                  <option value="Critical">Critical</option>
                </select>
              </div>
              <div className="mb-2">
                <label htmlFor="ticketSteps" className="form-label">
                  Steps to Reproduce:
                </label>
                <input
                  type="text"
                  id="ticketSteps"
                  className="form-control"
                  value={newTicketSteps}
                  onChange={(e) => onNewTicketStepsChange(e.target.value)}
                />
              </div>
              <div className="mb-2">
                <label htmlFor="ticketProjectId" className="form-label">
                  Project ID:
                </label>
                <input
                  type="number"
                  id="ticketProjectId"
                  className="form-control"
                  value={newTicketProjectId}
                  readOnly
                />
              </div>
              {/* Modal Footer inside form for accessibility (Alternatively, you can place it outside the form) */}
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={onCancelAddTicket}
                >
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Add Ticket
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddTicketForm;
