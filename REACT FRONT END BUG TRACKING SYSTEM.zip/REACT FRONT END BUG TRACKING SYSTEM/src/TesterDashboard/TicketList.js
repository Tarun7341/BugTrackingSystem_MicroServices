// src/components/TicketList.jsx
import React from "react";

const TicketList = ({ tickets }) => {
  return (
    <section>
      <h3>Tickets List</h3>
      {tickets && tickets.length > 0 ? (
        <ul>
          {tickets.map((ticket) => (
            <li key={ticket.id}>{ticket.title}</li>
          ))}
        </ul>
      ) : (
        <p>No tickets available.</p>
      )}
    </section>
  );
};

export default TicketList;
