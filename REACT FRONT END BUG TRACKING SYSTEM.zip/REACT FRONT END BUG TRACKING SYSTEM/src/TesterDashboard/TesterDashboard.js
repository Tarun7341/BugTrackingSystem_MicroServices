
import React, { useEffect, useState } from "react";
import { addTicket, updateTicket, deleteTicket } from "../api/bugService";
import api from "../api/axiosInstance";
import TicketTable from "./TicketTable";
import AddTicketForm from "./AddTicketForm";
import { decodeToken } from "../services/tokenService";
import Profile from "../components/Profile";

const TesterDashboard = () => {
  // Tickets State 
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);

  // States for adding a new ticket.
  const [newTicketTitle, setNewTicketTitle] = useState("");
  const [newTicketDescription, setNewTicketDescription] = useState("");
  const [newTicketStatus, setNewTicketStatus] = useState("");
  const [newTicketPriority, setNewTicketPriority] = useState(""); // Unused for tester.
  const [newTicketType, setNewTicketType] = useState("");
  const [newTicketSeverity, setNewTicketSeverity] = useState("");
  const [newTicketSteps, setNewTicketSteps] = useState("");
  const [newTicketProjectId, setNewTicketProjectId] = useState("");

  // States for editing an existing ticket.
  const [editingTicket, setEditingTicket] = useState(null);
  const [editingTicketUserIdsText, setEditingTicketUserIdsText] = useState("");

  //  Projects State 
  const [projects, setProjects] = useState([]);
  const [testerProjects, setTesterProjects] = useState([]);

  // Show/hide Add Ticket Form when a tester clicks "Raise Ticket"
  const [showAddTicketForm, setShowAddTicketForm] = useState(false);

  // Profile State 
  const [userProfile, setUserProfile] = useState(null);

  //  Navigation (Active Section) 
  // Possible values: "profile", "projects", "tickets"
  const [activeSection, setActiveSection] = useState("projects");

  // Data Fetching 
  const fetchTickets = async () => {
    try {
      const response = await api.get("/api/tickets/getAll");
      console.log("Tickets Response:", response.data);
      setTickets(response.data);
    } catch (err) {
      console.error("Error fetching tickets:", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchProjects = async () => {
    try {
      const response = await api.get("/api/projects/getAll");
      setProjects(response.data);
      // Filter to only include projects assigned to the tester.
      const token = localStorage.getItem("token");
      if (token) {
        const decoded = decodeToken(token);
        const testerId = Number(decoded.id);
        const filtered = response.data.filter((project) => {
          const projectUserIds = project.userId ? project.userId.map(Number) : [];
          return projectUserIds.includes(testerId);
        });
        setTesterProjects(filtered);
      }
    } catch (err) {
      console.error("Error fetching projects:", err);
    }
  };

  // Fetch the tester's profile (for the welcome message)
  const fetchProfile = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        console.error("No token found for the logged in user.");
        return;
      }
      const decoded = decodeToken(token);
      if (!decoded || !decoded.id) {
        console.error("Invalid token or missing user ID.");
        return;
      }
      const userId = decoded.id;
      const res = await api.get(`/api/users/getOne/${userId}`);
      setUserProfile(res.data);
    } catch (err) {
      console.error("Error fetching profile:", err);
    }
  };

  useEffect(() => {
    fetchTickets();
    fetchProjects();
    fetchProfile();
  }, []);

  //  Ticket Handlers 
  const handleAddTicket = async (e) => {
    e.preventDefault();
    try {
      const ticketData = {
        title: newTicketTitle,
        description: newTicketDescription,
        status: newTicketStatus,
        // tester cannot alter priority, so omitted.
        type: newTicketType,
        severity: newTicketSeverity,
        stepstoReproduce: newTicketSteps,
        projectId: newTicketProjectId ? parseInt(newTicketProjectId, 10) : null,
        userId: [] // default to empty.
      };
      await addTicket(ticketData);
      await fetchTickets();
      // Clear form fields.
      setNewTicketTitle("");
      setNewTicketDescription("");
      setNewTicketStatus("");
      setNewTicketPriority("");
      setNewTicketType("");
      setNewTicketSeverity("");
      setNewTicketSteps("");
      setNewTicketProjectId("");
      setShowAddTicketForm(false); // Hide the form on "Save"
    } catch (err) {
      console.error("Error adding ticket:", err);
    }
  };

  const handleCancelAddTicket = () => {
    // Reset the form fields if needed.
    setNewTicketTitle("");
    setNewTicketDescription("");
    setNewTicketStatus("");
    setNewTicketPriority("");
    setNewTicketType("");
    setNewTicketSeverity("");
    setNewTicketSteps("");
    setNewTicketProjectId("");
    setShowAddTicketForm(false);
  };

  const handleEditTicketClick = (ticket) => {
    setEditingTicket({
      ...ticket,
      userId: ticket.userId || [],
    });
    setEditingTicketUserIdsText(
      ticket.userId && ticket.userId.length ? ticket.userId.join(", ") : ""
    );
  };

  const handleCancelEdit = () => {
    setEditingTicket(null);
    setEditingTicketUserIdsText("");
  };

  const handleUpdateTicket = async (e) => {
    e.preventDefault();

    const userIdsArray = editingTicketUserIdsText
      .split(",")
      .map((str) => str.trim())
      .filter((str) => str !== "")
      .map((numStr) => parseInt(numStr, 10))
      .filter((num) => !isNaN(num));

    try {
      const updatedTicket = {
        id: editingTicket.id,
        title: editingTicket.title,
        description: editingTicket.description,
        status: editingTicket.status,
        priority: editingTicket.priority, // Remains unchanged.
        type: editingTicket.type,
        severity: editingTicket.severity,
        stepstoReproduce: editingTicket.stepstoReproduce,
        projectId: editingTicket.projectId,
        userId: userIdsArray,
      };
      await updateTicket(editingTicket.id, updatedTicket);
      await fetchTickets();
      setEditingTicket(null);
      setEditingTicketUserIdsText("");
    } catch (err) {
      console.error("Error updating ticket:", err);
    }
  };

  const handleDeleteTicket = async (ticketId) => {
    try {
      await deleteTicket(ticketId);
      await fetchTickets();
    } catch (err) {
      console.error("Error deleting ticket:", err);
    }
  };

  // --------------------- Project & Raise Ticket Handler ---------------------
  const handleRaiseTicket = (project) => {
    setNewTicketProjectId(project.id);
    // Switch to the Tickets view and reveal the Add Ticket Form.
    setActiveSection("tickets");
    setShowAddTicketForm(true);
  };

  //  Filter Tickets by Tester Projects
  const testerProjectIds = testerProjects.map((project) => project.id);
  const filteredTickets = tickets.filter((ticket) =>
    testerProjectIds.includes(ticket.projectId)
  );

  //  Render 
  if (loading) {
    return <p>Loading data...</p>;
  }

  return (
    <div>
      
      <nav
        style={{
          marginBottom: "20px",
          padding: "10px",
          backgroundColor: "#f1f1f1",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center"
        }}
      >
        
        <div>
          {userProfile ? (
            <h2 style={{ margin: 0 }}>
              Welcome {userProfile.firstname} {userProfile.lastname} -{" "}
              {userProfile.roles === "ROLE_TESTER" ? "{Tester}" : userProfile.roles}
            </h2>
          ) : (
            <h2 style={{ margin: 0 }}>Welcome, Tester</h2>
          )}
        </div>
        
        <div>
          <button
            className={`btn ${activeSection === "projects" ? "btn-primary" : "btn-secondary"} me-2`}
            onClick={() => setActiveSection("projects")}
          >
            Projects
          </button>
          <button
            className={`btn ${activeSection === "tickets" ? "btn-primary" : "btn-secondary"} me-2`}
            onClick={() => setActiveSection("tickets")}
          >
            Tickets
          </button>
          <button
            className={`btn ${activeSection === "profile" ? "btn-primary" : "btn-secondary"}`}
            onClick={() => setActiveSection("profile")}
          >
            Profile
          </button>
        </div>
      </nav>

    
      {activeSection === "profile" && (
        <section>
          <Profile />
        </section>
      )}

      {activeSection === "projects" && (
        <section>
          <h3>My Projects</h3>
          {testerProjects && testerProjects.length > 0 ? (
            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>Project ID</th>
                  <th>Project Name</th>
                  <th>Description</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {testerProjects.map((project) => (
                  <tr key={project.id}>
                    <td>{project.id}</td>
                    <td>{project.name}</td>
                    <td>{project.description}</td>
                    <td>
                      <button
                        className="btn btn-primary btn-sm"
                        onClick={() => handleRaiseTicket(project)}
                      >
                        Raise Ticket
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p>No projects assigned.</p>
          )}
        </section>
      )}

      {activeSection === "tickets" && (
        <section>
          <h3>Tickets</h3>
        
          {showAddTicketForm && (
            <AddTicketForm
              newTicketTitle={newTicketTitle}
              newTicketDescription={newTicketDescription}
              newTicketStatus={newTicketStatus}
              newTicketPriority={newTicketPriority}
              newTicketType={newTicketType}
              newTicketSeverity={newTicketSeverity}
              newTicketSteps={newTicketSteps}
              newTicketProjectId={newTicketProjectId}
              onNewTicketTitleChange={setNewTicketTitle}
              onNewTicketDescriptionChange={setNewTicketDescription}
              onNewTicketStatusChange={setNewTicketStatus}
              onNewTicketPriorityChange={setNewTicketPriority}
              onNewTicketTypeChange={setNewTicketType}
              onNewTicketSeverityChange={setNewTicketSeverity}
              onNewTicketStepsChange={setNewTicketSteps}
              onNewTicketProjectIdChange={setNewTicketProjectId}
              onAddTicket={handleAddTicket}
              onCancelAddTicket={handleCancelAddTicket}  
            />
          )}
          <TicketTable
            tickets={filteredTickets}
            editingTicket={editingTicket}
            editingTicketUserIdsText={editingTicketUserIdsText}
            onEditTicketClick={handleEditTicketClick}
            onCancelEdit={handleCancelEdit}
            onUpdateTicket={handleUpdateTicket}
            onDeleteTicket={handleDeleteTicket}
            onEditingTicketChange={setEditingTicket}
            onEditingTicketUserIdsTextChange={setEditingTicketUserIdsText}
          />
        </section>
      )}
    </div>
  );
};

export default TesterDashboard;
