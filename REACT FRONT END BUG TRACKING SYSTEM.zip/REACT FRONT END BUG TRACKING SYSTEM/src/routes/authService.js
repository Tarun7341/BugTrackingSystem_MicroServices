import axios from "axios";

const API_URL = `${"http://localhost:9096"}/api/auth`;

// In AuthService.js
export const login = async (credentials) => {
  try {
    const response = await axios.post(`${API_URL}/authenticate`, credentials);
    console.log("Server Response:", response.data);
    // If response.data is an object with a property "token", return that:
    return response.data.token || response.data;
  } catch (error) {
    console.error("Login Error:", error.response?.data || error.message);
    throw new Error("Login failed");
  }
};


export const getToken = () => localStorage.getItem("token");

export const logout = () => {
  localStorage.removeItem("token");
};
