import React, { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { Link, Navigate } from "react-router-dom";

const Home = () => {
  const { user, loading } = useContext(AuthContext);

  // While the auth state is being verified, show a loading indicator.
  if (loading) {
    return <div>Loading...</div>;
  }

  // If the user is authenticated, redirect them to their appropriate dashboard.
  if (user) {
    // Define the dashboard based on the user's role.
    // Adjust the logic as needed if a user has multiple roles.
    let dashboardUrl = "/"; // default route
    if (user.roles === "ROLE_ADMIN") {
      dashboardUrl = "/admin";
    } else if (user.roles === "ROLE_DEVELOPER") {
      dashboardUrl = "/developer";
    } else if (user.roles === "ROLE_TESTER") {
      dashboardUrl = "/tester";
    }
    
    return <Navigate to={dashboardUrl} />;
  }

  // Otherwise, allow access to the public home page with login/register options.
  return (
    <div className="container d-flex justify-content-center align-items-center vh-100">
      <div className="text-center p-5 border rounded shadow-lg bg-light">
        <h1 className="mb-3 text-primary">Bug Tracking System</h1>
        <p className="lead">Efficiently track and manage bugs in your projects.</p>
        <div className="mt-4">
          <Link to="/login" className="btn btn-primary me-3">
            Login
          </Link>
          <Link to="/register" className="btn btn-success">
            Register
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;
