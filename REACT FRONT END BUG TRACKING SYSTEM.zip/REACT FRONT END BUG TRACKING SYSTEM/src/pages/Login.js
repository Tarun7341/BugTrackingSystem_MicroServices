import { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import "bootstrap/dist/css/bootstrap.min.css";

const Login = () => {
  const { loginUser } = useContext(AuthContext);
  const [formData, setFormData] = useState({ username: "", password: "" });
  const [message, setMessage] = useState(null);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const loggedInUser = await loginUser(formData.username, formData.password);
      setMessage({ text: "Login Successful!", type: "success" });

      // Navigate immediately based on returned user data
      if (loggedInUser?.roles === "ROLE_ADMIN") {
        navigate("/admin");
      } else if (loggedInUser?.roles === "ROLE_DEVELOPER") {
        navigate("/developer");
      } else if (loggedInUser?.roles === "ROLE_TESTER") {
        navigate("/tester");
      } else {
        navigate("/");
      }
    } catch (error) {
      console.error("Login error:", error);
      setMessage({
        text: error.message || "Invalid credentials. Please try again.",
        type: "danger",
      });
    }

    setTimeout(() => setMessage(null), 3000);
  };

  return (
    <div className="container d-flex justify-content-center align-items-center vh-100">
      <div className="card p-4 shadow-lg" style={{ width: "400px" }}>
        <h2 className="text-center mb-4">Login</h2>

        {message && (
          <div className={`alert alert-${message.type} text-center`} role="alert">
            {message.text}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="username" className="form-label">Email</label>
            <input
              type="email"
              name="username"
              className="form-control"
              placeholder="Enter your email"
              value={formData.username}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="password" className="form-label">Password</label>
            <input
              type="password"
              name="password"
              className="form-control"
              placeholder="Enter your password"
              value={formData.password}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary w-100">Login</button>
        </form>
      </div>
    </div>
  );
};

export default Login;