import { useState } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";

const Register = () => {
  const [formData, setFormData] = useState({
    firstname: "",
    lastname: "",
    email: "",
    phoneNumber: "",
    password: "",
    roles: "",
  });
  const navigate = useNavigate();

  const roles = ["ROLE_ADMIN", "ROLE_DEVELOPER", "ROLE_TESTER"];

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    axios
      .post(`${process.env.REACT_APP_API_URL || "http://localhost:9096"}/api/auth/new`, formData)
      .then((response) => {
        console.log("User registered successfully!", response.data);
        alert("Registration successful! Please log in."); // You could also show a better inline message.
        navigate("/login"); // Redirect to login after registration
      })
      .catch((error) => {
        console.error("Registration error:", error);
        alert("Registration failed. Check console for details.");
      });
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center text-primary">User Registration</h2>
      <form onSubmit={handleSubmit} className="p-4 border rounded shadow bg-light">
        <div className="row g-3">
          <div className="col-md-6">
            <input
              type="text"
              name="firstname"
              className="form-control"
              placeholder="First Name"
              onChange={handleChange}
              required
            />
          </div>
          <div className="col-md-6">
            <input
              type="text"
              name="lastname"
              className="form-control"
              placeholder="Last Name"
              onChange={handleChange}
              required
            />
          </div>
          <div className="col-md-6">
            <input
              type="email"
              name="email"
              className="form-control"
              placeholder="Email"
              onChange={handleChange}
              required
            />
          </div>
          <div className="col-md-6">
            <input
              type="tel"
              name="phoneNumber"
              className="form-control"
              placeholder="Phone Number"
              onChange={handleChange}
              required
            />
          </div>
          <div className="col-md-6">
            <input
              type="password"
              name="password"
              className="form-control"
              placeholder="Password"
              onChange={handleChange}
              required
            />
          </div>
          <div className="col-md-6">
            <select name="roles" className="form-select" onChange={handleChange} required>
              <option value="">Select Role</option>
              {roles.map((role) => (
                <option key={role} value={role}>
                  {role.replace("ROLE_", "")}
                </option>
              ))}
            </select>
          </div>
        </div>
        <button type="submit" className="btn btn-primary w-100 mt-3">
          Register
        </button>
      </form>
    </div>
  );
};

export default Register;
