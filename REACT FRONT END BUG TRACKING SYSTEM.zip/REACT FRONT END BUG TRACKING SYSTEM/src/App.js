import { Routes, Route } from "react-router-dom";
import PrivateRoute from "./routes/PrivateRoute";
import Home from "./pages/Home";
import AdminDashboard from "./AdminDashboard/AdminDashbord";
import DeveloperDashboard from "./DeveloperDashboard/DeveloperDashboard";
import TesterDashboard from "./TesterDashboard/TesterDashboard";
import Login from "./pages/Login";
import Register from "./pages/Register";

function App() {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/" element={<Home />} />

      {/* Protected Routes */}
      <Route element={<PrivateRoute allowedRoles={["ROLE_ADMIN"]} />}>
        <Route path="/admin" element={<AdminDashboard />} />
      </Route>

      <Route element={<PrivateRoute allowedRoles={["ROLE_DEVELOPER"]} />}>
        <Route path="/developer" element={<DeveloperDashboard />} />
      </Route>

      <Route element={<PrivateRoute allowedRoles={["ROLE_TESTER"]} />}>
        <Route path="/tester" element={<TesterDashboard />} />
      </Route>
    </Routes>
  );
}

export default App;
