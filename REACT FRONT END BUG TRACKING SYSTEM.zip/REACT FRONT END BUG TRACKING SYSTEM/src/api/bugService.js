import api from "./axiosInstance";

const API_BASE_URL = "/api";

export const updateUser = async (userId, updatedData) => {
  const response = await api.put(`${API_BASE_URL}/users/update/${userId}`, updatedData);
  return response.data;
};

export const deleteUser = async (userId) => {
  const response = await api.delete(`${API_BASE_URL}/users/delete/${userId}`);
  return response.data;
};

// Project Management (Admin)
export const addProject = async (projectData) => {
  const response = await api.post(`${API_BASE_URL}/projects/addNew`, projectData);
  return response.data;
};

export const updateProject = async (projectId, updatedData) => {
  const response = await api.put(`${API_BASE_URL}/projects/update/${projectId}`, updatedData);
  return response.data;
};

export const deleteProject = async (projectId) => {
  const response = await api.delete(`${API_BASE_URL}/projects/delete/${projectId}`);
  return response.data;
};

export const removeUserFromProject = async (projectId, userIdToRemove) => {
  const response = await api.put(`${API_BASE_URL}/projects/removeUser/${projectId}/${userIdToRemove}`);
  return response.data;
};

// Ticket Management (Admin, Developer, Tester)
export const updateTicket = async (ticketId, updatedData) => {
  const response = await api.put(`${API_BASE_URL}/tickets/update/${ticketId}`, updatedData);
  return response.data;
};

export const removeUserFromTicket = async (ticketId, userIdToRemove) => {
  const response = await api.put(`${API_BASE_URL}/tickets/removeUser/${ticketId}/${userIdToRemove}`);
  return response.data;
};

export const addTicket = async (ticketData) => {
  const response = await api.post(`${API_BASE_URL}/tickets/addNew`, ticketData);
  return response.data;
};

export const deleteTicket = async (ticketId) => {
  const response = await api.delete(`${API_BASE_URL}/tickets/delete/${ticketId}`);
  return response.data;
};

export const getTicketById = async (ticketId) => {
  const response = await api.get(`${API_BASE_URL}/tickets/getOne/${ticketId}`);
  return response.data;
};


