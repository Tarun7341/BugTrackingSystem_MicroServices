import React, { useContext, useEffect, useState } from "react";
import api from "../api/axiosInstance";
import {
  addProject,
  updateProject,
  deleteProject,
  updateTicket,
  removeUserFromProject,
  removeUserFromTicket,
} from "../api/bugService";

import UsersSection from "./UsersSection";
import ProjectsSection from "./ProjectsSection";
import TicketAssignment from "./TicketAssignment";
import Profile from "../components/Profile";
import UserSelectionModal from "./UserSelectionModal";
import { decodeToken } from "../services/tokenService";
import { AuthContext } from "../context/AuthContext";



const AdminDashboard = () => {
  // --------------------- Section Toggle ---------------------
  // Controls which section (Users, Projects, Tickets, Profile) is visible.
  const {activeSection, setActiveSection} =useContext(AuthContext)

  // --------------------- Admin Profile State ---------------------
  const [adminProfile, setAdminProfile] = useState(null);
  const [loadingAdminProfile, setLoadingAdminProfile] = useState(true);

  // --------------------- Common States ---------------------
  const [users, setUsers] = useState([]);
  const [projects, setProjects] = useState([]);
  const [tickets, setTickets] = useState([]);
  const [ticketAssignmentTickets, setTicketAssignmentTickets] = useState([]);
  const [loading, setLoading] = useState(true);

  // Projects States 
  const [newProjectName, setNewProjectName] = useState("");
  const [newProjectDescription, setNewProjectDescription] = useState("");
  const [editingProject, setEditingProject] = useState(null);

  //  Ticket Assignment States 
  const [editingTicket, setEditingTicket] = useState(null);
  const [editingStatus, setEditingStatus] = useState("");
  const [editingPriority, setEditingPriority] = useState("");
  const [editingAssignedDeveloper, setEditingAssignedDeveloper] = useState("");
  // Allowed statuses for ticket updates.
  const allowedStatusOptions = ["Assigned", "In Progress", "Resolved", "Closed"];

  // User Selection Modal State 
  const [userSelectionData, setUserSelectionData] = useState(null);

  //  Data Fetching 
  const fetchAllData = async () => {
    try {
      const [usersRes, projectsRes, ticketsRes] = await Promise.all([
        api.get("/api/users/getAll"),
        api.get("/api/projects/getAll"),
        api.get("/api/tickets/getAll"),
      ]);
      setUsers(usersRes.data);
      setProjects(projectsRes.data);
      setTickets(ticketsRes.data);
      setTicketAssignmentTickets(ticketsRes.data);
    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
      setLoading(false);
    }
  };

  //  Fetch Admin Profile 
  useEffect(() => {
    const fetchAdminProfile = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) {
          console.error("No token found for the logged in user.");
          return;
        }
        const decodedToken = decodeToken(token);
        if (!decodedToken || !decodedToken.id) {
          console.error("Invalid token or missing user ID.");
          return;
        }
        const res = await api.get(`/api/users/getOne/${decodedToken.id}`);
        setAdminProfile(res.data);
      } catch (err) {
        console.error("Error fetching admin profile:", err);
      } finally {
        setLoadingAdminProfile(false);
      }
    };
    fetchAdminProfile();
  }, []);

  //  Fetch All Data on Mount 
  useEffect(() => {
    fetchAllData();
  }, []);

  //  Project Handlers 
  const handleAddProject = async (e) => {
    e.preventDefault();
    try {
      const projectData = {
        name: newProjectName,
        description: newProjectDescription,
        userId: [],
      };
      await addProject(projectData);
      await fetchAllData();
      setNewProjectName("");
      setNewProjectDescription("");
    } catch (err) {
      console.error("Error adding project:", err);
    }
  };

  const handleEditProjectClick = (project) => {
    setEditingProject({ ...project, userId: project.userId || [] });
  };

  const handleCancelEditProject = () => {
    setEditingProject(null);
  };

  const handleUpdateProject = async (e) => {
    e.preventDefault();
    try {
      const updatedData = {
        name: editingProject.name,
        description: editingProject.description,
        userId: editingProject.userId || [],
      };
      await updateProject(editingProject.id, updatedData);
      await fetchAllData();
      setEditingProject(null);
    } catch (err) {
      console.error("Error updating project:", err);
    }
  };

  const handleDeleteProject = async (projectId) => {
    try {
      await deleteProject(projectId);
      await fetchAllData();
    } catch (err) {
      console.error("Error deleting project:", err);
    }
  };

  //  User Selection Modal Handlers for Projects 
  const handleOpenUserSelection = async (projectId, role, mode) => {
    try {
      const response = await api.get("/api/users/ids-and-names");
      let usersData = response.data; // [{ id, firstname, lastname, roles }, ... ]
      const requiredRole = role === "developer" ? "ROLE_DEVELOPER" : "ROLE_TESTER";
      usersData = usersData.filter((user) => user.roles === requiredRole);

      const project = projects.find((p) => p.id === projectId);
      if (!project) return;

      if (mode === "assign") {
        usersData = usersData.filter(
          (user) => !(project.userId || []).includes(user.id)
        );
      } else if (mode === "remove") {
        usersData = usersData.filter(
          (user) => (project.userId || []).includes(user.id)
        );
      }

      setUserSelectionData({
        isOpen: true,
        source: "project",
        projectId,
        role,
        mode,
        availableOptions: usersData,
        selectedUserIds: [],
      });
    } catch (error) {
      console.error("Error fetching user details", error);
    }
  };

  const handleCheckboxChange = (userId, checked) => {
    setUserSelectionData((prevData) => {
      if (!prevData) return prevData;
      let newSelected = prevData.selectedUserIds || [];
      if (checked) {
        if (!newSelected.includes(userId)) {
          newSelected.push(userId);
        }
      } else {
        newSelected = newSelected.filter((id) => id !== userId);
      }
      return { ...prevData, selectedUserIds: newSelected };
    });
  };

  const handleCancelUserSelection = () => {
    setUserSelectionData(null);
  };

  //  Ticket Assignment Handlers 
  const handleEditTicketClick = (ticket) => {
    setEditingTicket(ticket);
    const newStatus = allowedStatusOptions.includes(ticket.status)
      ? ticket.status
      : "Assigned";
    setEditingStatus(newStatus);
    setEditingPriority(ticket.priority || "");
    setEditingAssignedDeveloper(
      ticket.developerId ? ticket.developerId.toString() : ""
    );
  };

  const handleCancelEditTicket = () => {
    setEditingTicket(null);
    setEditingStatus("");
    setEditingPriority("");
    setEditingAssignedDeveloper("");
  };

  const handleUpdateTicket = async (ticketId) => {
    const updatedTicketData = {
      status: editingStatus,
      priority: editingPriority,
      developerId: editingAssignedDeveloper
        ? parseInt(editingAssignedDeveloper, 10)
        : null,
    };
    try {
      await updateTicket(ticketId, updatedTicketData);
      await fetchAllData();
      handleCancelEditTicket();
    } catch (err) {
      console.error("Error updating ticket:", err);
    }
  };

  //  Ticket-Specific User Selection Modal Handler 
  const handleOpenTicketUserSelection = async (ticketId, mode) => {
    const ticket = tickets.find((t) => t.id === ticketId);
    if (!ticket) {
      console.error(`Ticket with id ${ticketId} not found.`);
      return;
    }
    const project = projects.find((p) => p.id === ticket.projectId);
    if (!project) {
      console.error(`No project found for ticket id ${ticketId}.`);
      return;
    }

    let availableOptions = [];
    if (mode === "assign") {
      availableOptions = users
        .filter(
          (user) =>
            project.userId &&
            project.userId.includes(user.id) &&
            user.roles === "ROLE_DEVELOPER"
        )
        .filter((user) => !ticket.userId.includes(user.id));
    } else if (mode === "remove") {
      availableOptions = users.filter((user) => {
        return (
          ticket.userId &&
          ticket.userId.includes(user.id) &&
          user.roles === "ROLE_DEVELOPER"
        );
      });
    }

    setUserSelectionData({
      isOpen: true,
      source: "ticket",
      ticketId,
      mode,
      role: "developer",
      availableOptions,
      selectedUserIds: [],
    });
  };

  //  Confirmation Handler for User Selection Modal 
  const handleConfirmUserSelection = async () => {
    if (!userSelectionData) return;
  
    // Projects Assignment
    if (userSelectionData.source === "project") {
      const { projectId, mode, selectedUserIds } = userSelectionData;
      const project = projects.find((p) => p.id === projectId);
      if (!project) {
        console.error("Project not found for id", projectId);
        return;
      }
      try {
        if (mode === "assign") {
          let updatedUserIds = project.userId ? [...project.userId] : [];
          selectedUserIds.forEach((id) => {
            if (!updatedUserIds.includes(id)) {
              updatedUserIds.push(id);
            }
          });
          await updateProject(project.id, { userId: updatedUserIds });
        } else if (mode === "remove") {
          for (let i = 0; i < selectedUserIds.length; i++) {
            await removeUserFromProject(project.id, selectedUserIds[i]);
          }
        }
        await fetchAllData();
        setUserSelectionData(null);
      } catch (err) {
        console.error("Error updating project assignment:", err);
      }
    }
    // Tickets Assignment
    else if (userSelectionData.source === "ticket") {
      const { ticketId, mode, selectedUserIds } = userSelectionData;
      const ticket = tickets.find((t) => t.id === ticketId);
      if (!ticket) {
        console.error("Ticket not found for id", ticketId);
        return;
      }
      try {
        if (mode === "assign") {
          if (selectedUserIds && selectedUserIds.length > 0) {
            const payload = {
              status: editingStatus || ticket.status || "Assigned",
              priority: editingPriority || ticket.priority || "",
              userId: selectedUserIds,
            };
            const updatedTicket = await updateTicket(ticketId, payload);
            if (updatedTicket && typeof updatedTicket === "object") {
              setTicketAssignmentTickets((prevTickets) =>
                prevTickets.map((t) =>
                  t.id === ticketId ? updatedTicket : t
                )
              );
            } else {
              await fetchAllData();
            }
          } else {
            console.warn("No developer selected for ticket assignment.");
          }
        } else if (mode === "remove") {
          for (let selectedUserId of selectedUserIds) {
            if (ticket.userId && ticket.userId.includes(selectedUserId)) {
              await removeUserFromTicket(ticketId, selectedUserId);
            } else {
              console.warn(
                `No developer assigned to ticket ${ticketId} for removal of user ${selectedUserId}.`
              );
            }
          }
        }
        await fetchAllData();
        setUserSelectionData(null);
      } catch (err) {
        console.error("Error updating ticket assignment:", err);
      }
    }
  };

  //  Logout Handler 
  const handleLogout = () => {
    console.log("Logging out...");
    // Insert your logout logic here.
  };

  //  Render
  return (
    <div>
      <nav
        style={{
          marginBottom: "20px",
          padding: "10px",
          backgroundColor: "#f1f1f1",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        {/* Left: Welcome Message */}
        <div>
  <h2 style={{ margin: 0 }}>
    Welcome{" "}
    {adminProfile
      ? `${adminProfile.firstname || adminProfile.firstName || "Admin"} ${adminProfile.lastname || adminProfile.lastName || ""}`
      : "Admin"}{" "}
    -{" "}
    {adminProfile && adminProfile.roles === "ROLE_ADMIN" ? "{Admin}" : ""}
  </h2>
</div>

        {/* Right: Navigation Buttons */}
        <div>
          <button
            className={`btn ${
              activeSection === "users" ? "btn-primary" : "btn-secondary"
            }`}
            onClick={() => setActiveSection("users")}
            style={{ marginRight: "10px" }}
          >
            Users
          </button>
          <button
            className={`btn ${
              activeSection === "projects" ? "btn-primary" : "btn-secondary"
            }`}
            onClick={() => setActiveSection("projects")}
            style={{ marginRight: "10px" }}
          >
            Projects
          </button>
          <button
            className={`btn ${
              activeSection === "tickets" ? "btn-primary" : "btn-secondary"
            }`}
            onClick={() => setActiveSection("tickets")}
            style={{ marginRight: "10px" }}
          >
            Tickets
          </button>
          <button
            className={`btn ${
              activeSection === "profile" ? "btn-primary" : "btn-secondary"
            }`}
            onClick={() => setActiveSection("profile")}
          >
            Profile
          </button>
        </div>
      </nav>

      {/* Main Content */}
      {loading ? (
        <p>Loading data...</p>
      ) : (
        <>
          {activeSection === "profile" && <Profile onLogout={handleLogout} />}
          {activeSection === "users" && (
            <UsersSection users={users} refreshUsers={fetchAllData} />
          )}
          {activeSection === "projects" && (
            <ProjectsSection
              users={users}
              projects={projects}
              editingProject={editingProject}
              newProjectName={newProjectName}
              newProjectDescription={newProjectDescription}
              onAddProject={handleAddProject}
              onEditProjectClick={handleEditProjectClick}
              onCancelEditProject={handleCancelEditProject}
              onUpdateProject={handleUpdateProject}
              onDeleteProject={handleDeleteProject}
              onNewProjectNameChange={setNewProjectName}
              onNewProjectDescriptionChange={setNewProjectDescription}
              onEditingProjectChange={setEditingProject}
              onOpenUserSelection={handleOpenUserSelection}
            />
          )}
          {activeSection === "tickets" && (
            <TicketAssignment
              tickets={ticketAssignmentTickets}
              editingTicket={editingTicket}
              editingStatus={editingStatus}
              editingPriority={editingPriority}
              editingAssignedDeveloper={editingAssignedDeveloper}
              allowedStatusOptions={allowedStatusOptions}
              onEditTicketClick={handleEditTicketClick}
              onCancelEditTicket={handleCancelEditTicket}
              onUpdateTicket={handleUpdateTicket}
              onEditingStatusChange={setEditingStatus}
              onEditingPriorityChange={setEditingPriority}
              onEditingAssignedDeveloperChange={setEditingAssignedDeveloper}
              projects={projects}
              users={users}
              handleOpenTicketUserSelection={handleOpenTicketUserSelection}
            />
          )}
        </>
      )}

      {/* User Selection Modal */}
      {userSelectionData && (
        <UserSelectionModal
          isOpen={userSelectionData.isOpen}
          availableOptions={userSelectionData.availableOptions}
          selectedUserIds={userSelectionData.selectedUserIds}
          onCheckboxChange={handleCheckboxChange}
          onConfirm={handleConfirmUserSelection}
          onCancel={handleCancelUserSelection}
          title={
            userSelectionData.mode === "assign"
              ? `Assign ${
                  userSelectionData.source === "project"
                    ? userSelectionData.role === "developer"
                      ? "Developer(s)"
                      : "Tester(s)"
                    : "Ticket Developer(s)"
                }`
              : `Remove ${
                  userSelectionData.source === "project"
                    ? userSelectionData.role === "developer"
                      ? "Developer(s)"
                      : "Tester(s)"
                    : "Ticket Developer(s)"
                }`
          }
        />
      )}
    </div>
  );
};

export default AdminDashboard;
