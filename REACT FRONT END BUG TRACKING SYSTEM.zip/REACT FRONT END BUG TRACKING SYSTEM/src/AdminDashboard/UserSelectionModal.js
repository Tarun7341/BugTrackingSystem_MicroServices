// src/components/UserSelectionModal.jsx
import React from "react";

const UserSelectionModal = ({
  isOpen,
  availableOptions,
  selectedUserIds,
  onCheckboxChange,
  onConfirm,
  onCancel,
  title,
}) => {
  if (!isOpen) return null;
  return (
    <div
      className="modal show"
      style={{
        display: "block",
        backgroundColor: "rgba(0,0,0,0.5)",
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        zIndex: 1050,
      }}
    >
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">{title}</h5>
            <button type="button" className="btn-close" onClick={onCancel}></button>
          </div>
          <div className="modal-body">
            {console.log("availableOptions "+ availableOptions)}
            {availableOptions && availableOptions.length > 0 ? (
              availableOptions.map((user) => (
                <div key={user.id} className="form-check">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    value={user.id}
                    checked={selectedUserIds.includes(user.id)}
                    onChange={(e) =>
                      onCheckboxChange(user.id, e.target.checked)
                    }
                    id={`user-checkbox-${user.id}`}
                  />
                  <label
                    className="form-check-label"
                    htmlFor={`user-checkbox-${user.id}`}
                  >
                    {user.id} - {user.firstname} {user.lastname}
                  </label>
                </div>
              ))
            ) : (
                
              <p>No users available.</p>
            )}
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onCancel}>
              Cancel
            </button>
            <button type="button" className="btn btn-primary" onClick={onConfirm}>
              Confirm
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserSelectionModal;
