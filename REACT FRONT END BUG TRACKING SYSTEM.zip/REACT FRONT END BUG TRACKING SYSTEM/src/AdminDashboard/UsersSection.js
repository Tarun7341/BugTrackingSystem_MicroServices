// src/components/UsersSection.jsx
import React, { useState } from "react";
import { updateUser, deleteUser } from "../api/bugService";

const UsersSection = ({ users, refreshUsers }) => {
  const [editingUserId, setEditingUserId] = useState(null);
  const [editFormData, setEditFormData] = useState({});

  // When "Edit" is clicked, store that user's data in local state for editing
  const handleEditClick = (user) => {
    setEditingUserId(user.id);
    setEditFormData(user);
  };

  // Update the local state as data is modified in the input fields
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditFormData({
      ...editFormData,
      [name]: value,
    });
  };

  // Save the changes for a specific user
  const handleSave = async (userId) => {
    try {
      await updateUser(userId, editFormData);
      setEditingUserId(null);
      refreshUsers();
    } catch (err) {
      console.error("Error updating user:", err);
    }
  };

  // Cancel editing: clear the editing state
  const handleCancel = () => {
    setEditingUserId(null);
  };

  // Delete the user and refresh the list after deletion
  const handleDelete = async (userId) => {
    try {
      await deleteUser(userId);
      refreshUsers();
    } catch (err) {
      console.error("Error deleting user:", err);
    }
  };

  return (
    <section>
      <h3>Users</h3>
      {users && users.length > 0 ? (
        <table className="table table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Phone Number</th>
              <th>Roles</th>
              <th style={{ width: "200px" }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <td>{user.id}</td>
                {editingUserId === user.id ? (
                  <>
                    <td>
                      <input
                        type="text"
                        name="firstname"
                        value={editFormData.firstname || ""}
                        onChange={handleInputChange}
                        className="form-control"
                      />
                    </td>
                    <td>
                      <input
                        type="text"
                        name="lastname"
                        value={editFormData.lastname || ""}
                        onChange={handleInputChange}
                        className="form-control"
                      />
                    </td>
                    <td>
                      <input
                        type="email"
                        name="email"
                        value={editFormData.email || ""}
                        onChange={handleInputChange}
                        className="form-control"
                      />
                    </td>
                    <td>
                      <input
                        type="text"
                        name="phoneNumber"
                        value={editFormData.phoneNumber || ""}
                        onChange={handleInputChange}
                        className="form-control"
                      />
                    </td>
                    <td>
                      <input
                        type="text"
                        name="roles"
                        value={editFormData.roles || ""}
                        onChange={handleInputChange}
                        className="form-control"
                      />
                    </td>
                    <td>
                      <button
                        className="btn btn-success btn-sm me-2"
                        onClick={() => handleSave(user.id)}
                      >
                        Save
                      </button>
                      <button
                        className="btn btn-secondary btn-sm me-2"
                        onClick={handleCancel}
                      >
                        Cancel
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleDelete(user.id)}
                      >
                        Delete
                      </button>
                    </td>
                  </>
                ) : (
                  <>
                    <td>{user.firstname}</td>
                    <td>{user.lastname}</td>
                    <td>{user.email}</td>
                    <td>{user.phoneNumber}</td>
                    <td>{user.roles}</td>
                    <td>
                      <button
                        className="btn btn-primary btn-sm me-2"
                        onClick={() => handleEditClick(user)}
                      >
                        Edit
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleDelete(user.id)}
                      >
                        Delete
                      </button>
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No users available.</p>
      )}
    </section>
  );
};

export default UsersSection;
