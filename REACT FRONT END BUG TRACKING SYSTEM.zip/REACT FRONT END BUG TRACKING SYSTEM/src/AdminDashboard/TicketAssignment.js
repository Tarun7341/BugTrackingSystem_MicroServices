import React from "react";

const TicketAssignment = ({
  tickets,
  editingTicket,
  editingStatus,
  editingPriority,
  editingAssignedDeveloper,
  allowedStatusOptions,
  onEditTicketClick,
  onCancelEditTicket,
  onUpdateTicket,
  onEditingStatusChange,
  onEditingPriorityChange,
  onEditingAssignedDeveloperChange,
  projects,
  users,
  handleOpenTicketUserSelection,
}) => {
  // Helper function to return assigned developers as a comma-separated string.
  const getAssignedDevelopers = (ticket) => {
    const devs = users.filter(
      (u) =>
        ticket.userId &&
        ticket.userId.some((a) => Number(u.id) === Number(a)) &&
        u.roles === "ROLE_DEVELOPER"
    );
    return devs.length > 0
      ? devs.map((dev) => `${dev.firstname} ${dev.lastname}`).join(", ")
      : "-";
  };

  return (
    <section>
      <h3>Ticket Assignment</h3>
      <table className="table table-bordered table-striped">
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Status</th>
            <th>Priority</th>
            <th>Type</th>
            <th>Severity</th>
            <th>Project ID</th>
            <th>Assigned Developer</th>
            <th style={{ width: "200px" }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {tickets && tickets.length > 0 ? (
            tickets.map((ticket, index) =>
              editingTicket && editingTicket.id === ticket.id ? (
                // Editing row for the selected ticket.
                <tr key={`${ticket.id}-${index}`}>
                  <td>{ticket.id}</td>
                  <td>{ticket.title}</td>
                  <td>{ticket.description}</td>
                  <td>
                    <select
                      value={editingStatus}
                      onChange={(e) => onEditingStatusChange(e.target.value)}
                      className="form-select form-select-sm"
                    >
                      {allowedStatusOptions.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td>
                    <select
                      value={editingPriority}
                      onChange={(e) => onEditingPriorityChange(e.target.value)}
                      className="form-select form-select-sm"
                    >
                      {["Low", "Medium", "High"].map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td>{ticket.type}</td>
                  <td>{ticket.severity}</td>
                  <td>{ticket.projectId}</td>
                  <td>
                    <input
                      type="text"
                      value={editingAssignedDeveloper}
                      onChange={(e) =>
                        onEditingAssignedDeveloperChange(e.target.value)
                      }
                      className="form-control form-control-sm"
                    />
                  </td>
                  <td>
                    <button
                      className="btn btn-success btn-sm me-2"
                      onClick={() => onUpdateTicket(ticket.id)}
                    >
                      Save
                    </button>
                    <button
                      className="btn btn-secondary btn-sm"
                      onClick={onCancelEditTicket}
                    >
                      Cancel
                    </button>
                  </td>
                </tr>
              ) : (
                // Normal row: display all ticket fields.
                <tr key={`${ticket.id}-${index}`}>
                  <td>{ticket.id}</td>
                  <td>{ticket.title}</td>
                  <td>{ticket.description}</td>
                  <td>{ticket.status}</td>
                  <td>{ticket.priority || "-"}</td>
                  <td>{ticket.type || "-"}</td>
                  <td>{ticket.severity || "-"}</td>
                  <td>{ticket.projectId}</td>
                  <td>{getAssignedDevelopers(ticket)}</td>
                  <td>
                    <button
                      className="btn btn-primary btn-sm me-2"
                      onClick={() =>
                        handleOpenTicketUserSelection(ticket.id, "assign")
                      }
                    >
                      Assign Developer
                    </button>
                    <button
                      className="btn btn-danger btn-sm me-2"
                      onClick={() =>
                        handleOpenTicketUserSelection(ticket.id, "remove")
                      }
                    >
                      Remove Developer
                    </button>
                    <button
                      className="btn btn-secondary btn-sm"
                      onClick={() => onEditTicketClick(ticket)}
                    >
                      Edit Ticket
                    </button>
                  </td>
                </tr>
              )
            )
          ) : (
            <tr>
              <td colSpan="10">No tickets available.</td>
            </tr>
          )}
        </tbody>
      </table>
    </section>
  );
};

export default TicketAssignment;
