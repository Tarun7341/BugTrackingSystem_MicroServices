// src/components/ProjectsSection.jsx
import React, { useState } from "react";

const ProjectsSection = ({
  users,
  projects,
  editingProject,
  newProjectName,
  newProjectDescription,
  onAddProject,
  onEditProjectClick,
  onCancelEditProject,
  onUpdateProject,
  onDeleteProject,
  onNewProjectNameChange,
  onNewProjectDescriptionChange,
  onEditingProjectChange,
  onOpenUserSelection, // prop for opening the modal
}) => {
  // Local state to toggle the "Add New Project" form.
  const [showAddForm, setShowAddForm] = useState(false);

  // Helper function to get users assigned to a project filtered by role.
  const getAssignedUsers = (project, role) =>
    users.filter(
      (user) =>
        project.userId &&
        project.userId.includes(user.id) &&
        user.roles === (role === "developer" ? "ROLE_DEVELOPER" : "ROLE_TESTER")
    );

  // Wrap onAddProject handler to hide form on submission.
  const handleSubmit = (e) => {
    e.preventDefault();
    onAddProject(e);
    setShowAddForm(false);
  };

  return (
    <section>
      <h3>Projects</h3>
      
      {/* "Add Project" button */}
      {!showAddForm && (
        <button
          className="btn btn-success mb-3"
          onClick={() => setShowAddForm(true)}
        >
          Add Project
        </button>
      )}

      {/* Modal Pop-Up for "Add New Project" form */}
      {showAddForm && (
        <div
          className="modal fade show"
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0, 0, 0, 0.5)",
            display: "block",
            zIndex: 1050,
          }}
          tabIndex="-1"
        >
          <div className="modal-dialog">
            <div className="modal-content">
              {/* Modal Header */}
              <div className="modal-header">
                <h4 className="modal-title">Add New Project</h4>
                <button
                  type="button"
                  className="btn-close"
                  aria-label="Close"
                  onClick={() => setShowAddForm(false)}
                ></button>
              </div>
              {/* Modal Body */}
              <div className="modal-body">
                <form onSubmit={handleSubmit}>
                  <div className="mb-2">
                    <label htmlFor="projectName" className="form-label">
                      Project Name:
                    </label>
                    <input
                      type="text"
                      id="projectName"
                      className="form-control"
                      value={newProjectName}
                      onChange={(e) => onNewProjectNameChange(e.target.value)}
                      required
                    />
                  </div>
                  <div className="mb-2">
                    <label htmlFor="projectDescription" className="form-label">
                      Description:
                    </label>
                    <input
                      type="text"
                      id="projectDescription"
                      className="form-control"
                      value={newProjectDescription}
                      onChange={(e) =>
                        onNewProjectDescriptionChange(e.target.value)
                      }
                      required
                    />
                  </div>
                  <div>
                    <button type="submit" className="btn btn-primary me-2">
                      Add Project
                    </button>
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={() => setShowAddForm(false)}
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Projects Table */}
      <table className="table table-bordered table-striped">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Assigned Developers</th>
            <th>Developer Actions</th>
            <th>Assigned Testers</th>
            <th>Tester Actions</th>
            <th style={{ width: "250px" }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {projects && projects.length > 0 ? (
            projects.map((project) => {
              const assignedDevelopers = getAssignedUsers(project, "developer");
              const assignedTesters = getAssignedUsers(project, "tester");

              return (
                <tr key={project.id}>
                  <td>{project.id}</td>
                  <td>
                    {editingProject && editingProject.id === project.id ? (
                      <input
                        type="text"
                        className="form-control"
                        value={editingProject.name}
                        onChange={(e) =>
                          onEditingProjectChange({
                            ...editingProject,
                            name: e.target.value,
                          })
                        }
                      />
                    ) : (
                      project.name
                    )}
                  </td>
                  <td>
                    {editingProject && editingProject.id === project.id ? (
                      <input
                        type="text"
                        className="form-control"
                        value={editingProject.description}
                        onChange={(e) =>
                          onEditingProjectChange({
                            ...editingProject,
                            description: e.target.value,
                          })
                        }
                      />
                    ) : (
                      project.description
                    )}
                  </td>
                  <td>
                    {assignedDevelopers.length > 0
                      ? assignedDevelopers
                          .map(
                            (user) =>
                              `${user.id} - ${user.firstname} ${user.lastname}`
                          )
                          .join(", ")
                      : "-"}
                  </td>
                  <td>
                    <button
                      className="btn btn-primary btn-sm me-2"
                      onClick={() =>
                        onOpenUserSelection(project.id, "developer", "assign")
                      }
                    >
                      Assign Developer
                    </button>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() =>
                        onOpenUserSelection(project.id, "developer", "remove")
                      }
                    >
                      Remove Developer
                    </button>
                  </td>
                  <td>
                    {assignedTesters.length > 0
                      ? assignedTesters
                          .map(
                            (user) =>
                              `${user.id} - ${user.firstname} ${user.lastname}`
                          )
                          .join(", ")
                      : "-"}
                  </td>
                  <td>
                    <button
                      className="btn btn-primary btn-sm me-2"
                      onClick={() =>
                        onOpenUserSelection(project.id, "tester", "assign")
                      }
                    >
                      Assign Tester
                    </button>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() =>
                        onOpenUserSelection(project.id, "tester", "remove")
                      }
                    >
                      Remove Tester
                    </button>
                  </td>
                  <td>
                    {editingProject && editingProject.id === project.id ? (
                      <>
                        <button
                          className="btn btn-success btn-sm me-2"
                          onClick={onUpdateProject}
                        >
                          Save
                        </button>
                        <button
                          className="btn btn-secondary btn-sm"
                          onClick={onCancelEditProject}
                        >
                          Cancel
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          className="btn btn-primary btn-sm me-2"
                          onClick={() => onEditProjectClick(project)}
                        >
                          Edit
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => onDeleteProject(project.id)}
                        >
                          Delete
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              );
            })
          ) : (
            <tr>
              <td colSpan="8">No projects available.</td>
            </tr>
          )}
        </tbody>
      </table>
    </section>
  );
};

export default ProjectsSection;
