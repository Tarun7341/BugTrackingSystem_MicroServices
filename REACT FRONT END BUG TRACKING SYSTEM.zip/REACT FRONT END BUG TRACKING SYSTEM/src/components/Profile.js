import React, { useState, useEffect, useContext } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/axiosInstance";
import { updateUser } from "../api/bugService";
import { decodeToken } from "../services/tokenService";
import { AuthContext } from "../context/AuthContext";

const Profile = ({ onClose }) => {
  const [profile, setProfile] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({});

  // Grab the setActiveSection function from AuthContext
  const { setActiveSection } = useContext(AuthContext);
  const navigate = useNavigate(); // React Router's navigation hook

  // Fetch the user profile data when the component mounts
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) {
          console.error("No token found for the logged-in user.");
          return;
        }
        const decodedToken = decodeToken(token);
        if (!decodedToken || !decodedToken.id) {
          console.error("Invalid token or missing user ID.");
          return;
        }
        const userId = decodedToken.id;
        const res = await api.get(`/api/users/getOne/${userId}`);
        setProfile(res.data);
        setFormData(res.data);
      } catch (err) {
        console.error("Error fetching profile:", err);
      }
    };

    fetchProfile();
  }, []);

  // Handle profile updates
  const handleSave = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        console.error("No token found for the logged-in user.");
        return;
      }
      const decodedToken = decodeToken(token);
      if (!decodedToken || !decodedToken.id) {
        console.error("Invalid token or missing user ID.");
        return;
      }
      const userId = decodedToken.id;

      // Exclude fields that should not be updated
      const { roles, email, password, ...dataToUpdate } = formData;
      await updateUser(userId, dataToUpdate);
      setProfile({ ...profile, ...dataToUpdate });
      setEditMode(false);
    } catch (err) {
      console.error("Error updating profile:", err);
    }
  };

  // Safe close handler
  const handleClose = () => {
    setActiveSection("users");
    if (typeof onClose === "function") onClose();
  };

  // Logout handler: remove token and redirect to login page
  const handleLogout = () => {
    localStorage.removeItem("token");
    // Optionally, clear other authentication data if necessary
    navigate("/login"); // Redirect to the login page
  };

  return (
    <div
      className="modal fade show"
      style={{
        display: "block",
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        position: "fixed", // Ensure the modal stays on top
        top: 0,
        left: 0,
        width: "100vw",
        height: "100vh",
        zIndex: 1050,
      }}
      tabIndex="-1"
    >
      <div className="modal-dialog">
        <div className="modal-content">
          {/* Modal Header */}
          <div className="modal-header">
            <h2 className="modal-title">Profile</h2>
            <button
              type="button"
              className="btn-close"
              aria-label="Close"
              onClick={handleClose}
            ></button>
          </div>
          {/* Modal Body */}
          <div className="modal-body">
            {profile ? (
              <div>
                {editMode ? (
                  <div>
                    <div className="mb-2">
                      <label className="form-label">First Name:</label>
                      <input
                        type="text"
                        className="form-control"
                        value={formData.firstname || ""}
                        onChange={(e) =>
                          setFormData({ ...formData, firstname: e.target.value })
                        }
                      />
                    </div>
                    <div className="mb-2">
                      <label className="form-label">Last Name:</label>
                      <input
                        type="text"
                        className="form-control"
                        value={formData.lastname || ""}
                        onChange={(e) =>
                          setFormData({ ...formData, lastname: e.target.value })
                        }
                      />
                    </div>
                    <div className="mb-2">
                      <label className="form-label">Phone Number:</label>
                      <input
                        type="text"
                        className="form-control"
                        value={formData.phoneNumber || ""}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            phoneNumber: e.target.value,
                          })
                        }
                      />
                    </div>
                    <button
                      className="btn btn-success me-2"
                      onClick={handleSave}
                    >
                      Save
                    </button>
                    <button
                      className="btn btn-secondary"
                      onClick={() => setEditMode(false)}
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <div>
                    <p>
                      <strong>First Name:</strong>{" "}
                      {profile.firstname || profile.firstName}
                    </p>
                    <p>
                      <strong>Last Name:</strong>{" "}
                      {profile.lastname || profile.lastName}
                    </p>
                    <p>
                      <strong>Phone Number:</strong> {profile.phoneNumber}
                    </p>
                    <button
                      className="btn btn-primary me-2"
                      onClick={() => setEditMode(true)}
                    >
                      Edit Profile
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <p>Loading profile...</p>
            )}
          </div>
          {/* Modal Footer */}
          <div className="modal-footer">
            <button className="btn btn-danger me-auto" onClick={handleLogout}>
              Logout
            </button>
            <button className="btn btn-secondary" onClick={handleClose}>
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Assign a default prop for onClose in case it's not provided
Profile.defaultProps = {
  onClose: () => {},
};

export default Profile;
