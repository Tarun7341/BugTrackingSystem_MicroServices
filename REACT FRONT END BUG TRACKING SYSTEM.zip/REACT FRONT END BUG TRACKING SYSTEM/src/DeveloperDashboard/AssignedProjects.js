// src/components/AssignedProjects.jsx
import React from "react";

const AssignedProjects = ({ projects }) => {
  return (
    <div>
      <h3>Assigned Projects</h3>
      {projects && projects.length > 0 ? (
        <table className="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Project ID</th>
              <th>Name</th>
              <th>Description</th>
            </tr>
          </thead>
          <tbody>
            {projects.map((project) => (
              <tr key={project.id}>
                <td>{project.id}</td>
                <td>{project.name}</td>
                <td>{project.description}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No projects assigned.</p>
      )}
    </div>
  );
};

export default AssignedProjects;
