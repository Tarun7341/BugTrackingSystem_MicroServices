// src/components/AssignedTickets.jsx
import React from "react";

const AssignedTickets = ({
  tickets,
  editingTicketId,
  editingStatus,
  allowedStatusOptions,
  onEditTicket,        // invoked to initiate editing on a ticket
  onCancelEdit,        // clears editing state
  onUpdateTicketStatus, // updates the ticket's status
  onStartTicket,       // sets a ticket's status from "Assigned" to "In Progress"
  onStatusChange,      // updates the editing status value
}) => {
  return (
    <div>
      <h3>Assigned Tickets</h3>
      {tickets && tickets.length > 0 ? (
        <table className="table table-bordered table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Title</th>
              <th>Description</th>
              <th>Status</th>
              <th>Priority</th>
              <th>Type</th>
              <th>Severity</th>
              <th>Steps to Reproduce</th>
              <th>Project ID</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {tickets.map((ticket) => (
              <tr key={ticket.id}>
                <td>{ticket.id}</td>
                <td>{ticket.title}</td>
                <td>{ticket.description}</td>
                <td>
                  {editingTicketId === ticket.id ? (
                    <select
                      className="form-control"
                      value={editingStatus}
                      onChange={(e) => onStatusChange(e.target.value)}
                    >
                      {allowedStatusOptions.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  ) : (
                    ticket.status
                  )}
                </td>
                <td>{ticket.priority}</td>
                <td>{ticket.type}</td>
                <td>{ticket.severity}</td>
                <td>{ticket.stepstoReproduce}</td>
                <td>{ticket.projectId}</td>
                <td>
                  {ticket.status === "Assigned" && (
                    <button
                      className="btn btn-primary btn-sm"
                      onClick={() => onStartTicket(ticket.id)}
                    >
                      Start Ticket
                    </button>
                  )}
                  {ticket.status === "In Progress" && (
                    editingTicketId === ticket.id ? (
                      <>
                        <button
                          className="btn btn-success btn-sm me-2"
                          onClick={() =>
                            onUpdateTicketStatus(ticket.id, editingStatus)
                          }
                        >
                          Save
                        </button>
                        <button
                          className="btn btn-secondary btn-sm"
                          onClick={onCancelEdit}
                        >
                          Cancel
                        </button>
                      </>
                    ) : (
                      <button
                        className="btn btn-primary btn-sm"
                        onClick={() => onEditTicket(ticket.id, ticket.status)}
                      >
                        Edit Status
                      </button>
                    )
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No tickets assigned.</p>
      )}
    </div>
  );
};

export default AssignedTickets;
