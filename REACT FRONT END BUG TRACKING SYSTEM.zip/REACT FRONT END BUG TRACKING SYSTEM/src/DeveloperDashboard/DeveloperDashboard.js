// src/pages/DeveloperDashboard.jsx
import React, { useEffect, useState } from "react";
import api from "../api/axiosInstance";
import { updateTicket } from "../api/bugService";
import { decodeToken } from "../services/tokenService";
import AssignedProjects from "./AssignedProjects";
import AssignedTickets from "./AssignedTickets";
import Profile from "../components/Profile";

const DeveloperDashboard = () => {
  // State for the developer's profile.
  const [developerProfile, setDeveloperProfile] = useState(null);
  const [loadingProfile, setLoadingProfile] = useState(true);

  // States for projects and tickets (assigned to the developer).
  const [projects, setProjects] = useState([]);
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);

  // State for inline editing of a ticket’s status.
  const [editingTicketId, setEditingTicketId] = useState(null);
  const [editingStatus, setEditingStatus] = useState("");
  const allowedStatusOptions = ["In Progress", "Resolved", "Closed"];

  // New state for navigation between sections.
  // Possible values: "projects", "tickets", "profile".
  const [activeSection, setActiveSection] = useState("projects");

  
  // Fetch Developer Profile.
  const fetchProfile = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        console.error("No token found for the logged in user.");
        return;
      }
      const decoded = decodeToken(token);
      if (!decoded || !decoded.id) {
        console.error("Invalid token or missing user ID.");
        return;
      }
      const userId = decoded.id;
      const res = await api.get(`/api/users/getOne/${userId}`);
      setDeveloperProfile(res.data);
    } catch (err) {
      console.error("Error fetching developer profile:", err);
    } finally {
      setLoadingProfile(false);
    }
  };

  // --------------------------------------------------------------------------------
  // Fetch Projects and Tickets assigned to the developer.
  const fetchData = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        console.error("No token found for data fetch.");
        return;
      }
      const decoded = decodeToken(token);
      const userId = decoded.id;
      const projectsRes = await api.get(`/api/projects/getProjectsByUserId/${userId}`);
      const ticketsRes = await api.get(`/api/tickets/users/${userId}`);
      setProjects(projectsRes.data);
      setTickets(ticketsRes.data);
    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
    fetchData();
  }, []);

  // --------------------------------------------------------------------------------
  // Ticket Handlers.
  const handleUpdateTicketStatus = async (ticketId, newStatus) => {
    try {
      await updateTicket(ticketId, { status: newStatus });
      // Re-fetch data for consistency.
      await fetchData();
      setEditingTicketId(null);
      setEditingStatus("");
    } catch (err) {
      console.error("Error updating ticket status:", err);
    }
  };

  const handleStartTicket = async (ticketId) => {
    try {
      await updateTicket(ticketId, { status: "In Progress" });
      await fetchData();
    } catch (err) {
      console.error("Error starting ticket:", err);
    }
  };

  const handleEditTicket = (ticketId, currentStatus) => {
    setEditingTicketId(ticketId);
    setEditingStatus(currentStatus);
  };

  const handleCancelEdit = () => {
    setEditingTicketId(null);
    setEditingStatus("");
  };

  // --------------------------------------------------------------------------------
  // Render.
  if (loadingProfile || loading) {
    return <p>Loading data...</p>;
  }

  return (
    <div>
      {/* Navigation Bar */}
      <nav
        style={{
          marginBottom: "20px",
          padding: "10px",
          backgroundColor: "#f1f1f1",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        {/* Left Side: Welcome Message */}
        <div>
          <h2 style={{ margin: 0 }}>
            Welcome{" "}
            {developerProfile
              ? `${developerProfile.firstname || developerProfile.firstName || "Developer"} ${developerProfile.lastname || developerProfile.lastName || ""}`
              : "Developer"}{" "}
            -{" "}
            {developerProfile && developerProfile.roles === "ROLE_DEVELOPER"
              ? "{Developer}"
              : ""}
          </h2>
        </div>
        {/* Right Side: Navigation Buttons (Profile is rightmost) */}
        <div>
          <button
            className={`btn ${activeSection === "projects" ? "btn-primary" : "btn-secondary"} me-2`}
            onClick={() => setActiveSection("projects")}
          >
            Projects
          </button>
          <button
            className={`btn ${activeSection === "tickets" ? "btn-primary" : "btn-secondary"} me-2`}
            onClick={() => setActiveSection("tickets")}
          >
            Tickets
          </button>
          <button
            className={`btn ${activeSection === "profile" ? "btn-primary" : "btn-secondary"}`}
            onClick={() => setActiveSection("profile")}
          >
            Profile
          </button>
        </div>
      </nav>

      {/* Conditionally Render Sections */}
      {activeSection === "profile" && (
        <section>
          <Profile />
        </section>
      )}

      {activeSection === "projects" && (
        <section>
          <AssignedProjects projects={projects} />
        </section>
      )}

      {activeSection === "tickets" && (
        <section>
          <AssignedTickets
            tickets={tickets}
            editingTicketId={editingTicketId}
            editingStatus={editingStatus}
            allowedStatusOptions={allowedStatusOptions}
            onEditTicket={handleEditTicket}
            onCancelEdit={handleCancelEdit}
            onUpdateTicketStatus={handleUpdateTicketStatus}
            onStartTicket={handleStartTicket}
            onStatusChange={setEditingStatus}
          />
        </section>
      )}
    </div>
  );
};

export default DeveloperDashboard;
